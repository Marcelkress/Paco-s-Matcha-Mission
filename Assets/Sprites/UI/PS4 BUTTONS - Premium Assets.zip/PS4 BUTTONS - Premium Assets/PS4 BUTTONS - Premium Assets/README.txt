---THANK YOU---
Thank you for showing interest in this project.
- Made by Arks @scissormarks


---SPECIFICATION---
- This assetspack contains 113 different input elements.
- Each input has a respective SVG (vector file) and PNG. (image file at 480px*480px)
- The files contained in this pack has been sorted into groups based on input type.
- Some inputs have different variations - these can be used based on preference or for state changes like when holding down an input.
- The font used for the project is Open Sans - Semibold which is a free to use font type. (https://fonts.google.com/specimen/Open+Sans=


---CONTENT OF ASSETPACK--- (231 files)
- ROOT (5 files)
- Analogue Blank Inputs (32 files)
- Analogue L Inputs (32 files)
- Analogue R Inputs (32 files)
- Directional Arrows (36 files)
- Main Buttons (36 files)
- Other Inputs (14 files)
- R and L Inputs (44 files)


---ACCREDITATION---
The accredidation for the work should be label as "UI Elements" (or something to a similar effect) crediting "Mikkel Julian 'Arks' Petersen" or "Arks @Scissormarks" and if relevant; should including these social media links:
- @ScissorMarks (on twitter)
- https://arks.itch.io
- https://arks.itch.io/ps4-buttons


---SOCIAL LINKS---
https://arks.itch.io/
https://twitter.com/ScissorMarks
https://arksiscool.uwu.ai/


---LEGAL---
*Playstation® and the Playstation® logo are registered trademarks of Sony Interactive Entertainment.